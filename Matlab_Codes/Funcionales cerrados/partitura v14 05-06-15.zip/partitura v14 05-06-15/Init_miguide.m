function Init_miguide()    %----- Datos del usuario -----%
    
    addpath('D:\UTN\DPLAB\Grupo_Audio\repositorio_svn - copia\mFunction'); % Ruta de funciones auxiliares *.m
    
    global app_id;
    global audio_text;
    global wlen_text;
    global window_length;
    global in_total;
    global freq_samp;
    global iter_bloque;
    global iter_muestra;
    
    
    iter_bloque(app_id) = 1;
    iter_muestra(app_id) = 1;
    
    
    filename = get(audio_text(app_id), 'string');

    disp(['Cargando Audio "' filename '" ...']);
    
    % filename = '../Audios/G_1_8k.wav';
    
    window_length(app_id) = str2num(get(wlen_text(app_id), 'string'));
    
    [aux_in, aux_fs] = wavread(filename);                  % Cargo audio
    
    disp(['Cargo audio']);
    aux_in = aux_in(:,1);
    aux_in = aux_in / max(abs(aux_in));
    %aux_in = Reduce_vector(aux_in, 0.005);
    aux_in = Complete_vector(aux_in', window_length(app_id))'; % Completo con tantos ceros al final del vector de entrada tal que su longitud sea divisible por el tama�o de la ventana
    
    
    if ~isempty(in_total)
        in_total = wextend('addcol','zpd',in_total,1,'r');
        if length(in_total(:,1)) < length(aux_in)
            in_total = wextend('addrow','zpd',in_total,length(aux_in)-length(in_total(:,1)),'r');
        end
    else
        in_total = zeros(length(aux_in),1);
    end
    
    in_total(:,app_id) = wextend('addrow', 'zpd', aux_in, length(in_total(:,1))-length(aux_in), 'r');                             % Tomo un solo canal
    freq_samp(app_id) = aux_fs;
    
    disp(['Audio "' filename '" cargado correctamente']);
    
    [~,name,ext] = fileparts(filename);
    
    set(gcf,'name',[name '.' ext],'NumberTitle','off');

end