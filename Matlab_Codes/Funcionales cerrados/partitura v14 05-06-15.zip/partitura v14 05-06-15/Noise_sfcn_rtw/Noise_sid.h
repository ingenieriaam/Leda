/*
 * Noise_sid.h
 *
 * Code generation for model "Noise_sf".
 *
 * Model version              : 1.86
 * Simulink Coder version : 8.5 (R2013b) 08-Aug-2013
 * C source code generated on : Sat Jun 06 03:19:03 2015
 *
 * Target selection: rtwsfcn.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: TI C6000
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 *
 * SOURCES: Noise_sf.c
 */

/* statically allocated instance data for model: Noise */
{
  {
    /* Local SimStruct for the generated S-Function */
    static LocalS slS;
    LocalS *lS = &slS;
    ssSetUserData(rts, lS);

    /* block I/O */
    {
      static B_Noise_T sfcnB;
      void *b = (real_T *) &sfcnB;
      ssSetLocalBlockIO(rts, b);

      {
        int_T i;
        for (i = 0; i < 256; i++) {
          ((B_Noise_T *) ssGetLocalBlockIO(rts))->MinMax[i] = 0.0;
        }

        for (i = 0; i < 256; i++) {
          ((B_Noise_T *) ssGetLocalBlockIO(rts))->ManualSwitch1[i] = 0.0F;
        }

        for (i = 0; i < 256; i++) {
          ((B_Noise_T *) ssGetLocalBlockIO(rts))->Delay[i] = 0.0F;
        }

        for (i = 0; i < 256; i++) {
          ((B_Noise_T *) ssGetLocalBlockIO(rts))->Mean[i] = 0.0F;
        }
      }
    }

    /* model checksums */
    ssSetChecksumVal(rts, 0, 3470965051U);
    ssSetChecksumVal(rts, 1, 1974435939U);
    ssSetChecksumVal(rts, 2, 4282695927U);
    ssSetChecksumVal(rts, 3, 3069817036U);
  }
}
