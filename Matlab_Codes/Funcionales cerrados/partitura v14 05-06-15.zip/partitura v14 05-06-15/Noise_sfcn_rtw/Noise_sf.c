/*
 * Noise_sf.c
 *
 * Code generation for model "Noise_sf".
 *
 * Model version              : 1.86
 * Simulink Coder version : 8.5 (R2013b) 08-Aug-2013
 * C source code generated on : Sat Jun 06 03:19:03 2015
 *
 * Target selection: rtwsfcn.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: TI C6000
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include <math.h>
#include "Noise_sf.h"
#include "Noise_sf_private.h"
#include "simstruc.h"
#include "fixedpoint.h"
#if defined(RT_MALLOC) || defined(MATLAB_MEX_FILE)

extern void *Noise_malloc(SimStruct *S);

#endif

#ifndef __RTW_UTFREE__
#if defined (MATLAB_MEX_FILE)

extern void * utMalloc(size_t);
extern void utFree(void *);

#endif
#endif                                 /* #ifndef __RTW_UTFREE__ */

/* Forward declaration for local functions */
static real32_T Noise_rt_hypotf_snf(real32_T u0, real32_T u1);
static real32_T Noise_rt_powf_snf(real32_T u0, real32_T u1);
static real32_T Noise_rt_atan2f_snf(real32_T u0, real32_T u1);

#if defined(MATLAB_MEX_FILE)
#include "rt_nonfinite.c"
#endif

static const char_T *RT_MEMORY_ALLOCATION_ERROR =
  "memory allocation error in generated S-Function";
static real32_T Noise_rt_hypotf_snf(real32_T u0, real32_T u1)
{
  real32_T y;
  real32_T a;
  real32_T b;
  a = (real32_T)fabs(u0);
  b = (real32_T)fabs(u1);
  if (a < b) {
    a /= b;
    y = (real32_T)sqrt(a * a + 1.0F) * b;
  } else if (a > b) {
    b /= a;
    y = (real32_T)sqrt(b * b + 1.0F) * a;
  } else if (rtIsNaNF(b)) {
    y = b;
  } else {
    y = a * 1.41421354F;
  }

  return y;
}

static real32_T Noise_rt_powf_snf(real32_T u0, real32_T u1)
{
  real32_T y;
  real32_T tmp;
  real32_T tmp_0;
  if (rtIsNaNF(u0) || rtIsNaNF(u1)) {
    y = (rtNaNF);
  } else {
    tmp = (real32_T)fabs(u0);
    tmp_0 = (real32_T)fabs(u1);
    if (rtIsInfF(u1)) {
      if (tmp == 1.0F) {
        y = (rtNaNF);
      } else if (tmp > 1.0F) {
        if (u1 > 0.0F) {
          y = (rtInfF);
        } else {
          y = 0.0F;
        }
      } else if (u1 > 0.0F) {
        y = 0.0F;
      } else {
        y = (rtInfF);
      }
    } else if (tmp_0 == 0.0F) {
      y = 1.0F;
    } else if (tmp_0 == 1.0F) {
      if (u1 > 0.0F) {
        y = u0;
      } else {
        y = 1.0F / u0;
      }
    } else if (u1 == 2.0F) {
      y = u0 * u0;
    } else if ((u1 == 0.5F) && (u0 >= 0.0F)) {
      y = (real32_T)sqrt(u0);
    } else if ((u0 < 0.0F) && (u1 > (real32_T)floor(u1))) {
      y = (rtNaNF);
    } else {
      y = (real32_T)pow(u0, u1);
    }
  }

  return y;
}

static real32_T Noise_rt_atan2f_snf(real32_T u0, real32_T u1)
{
  real32_T y;
  int32_T u;
  int32_T u_0;
  if (rtIsNaNF(u0) || rtIsNaNF(u1)) {
    y = (rtNaNF);
  } else if (rtIsInfF(u0) && rtIsInfF(u1)) {
    if (u0 > 0.0F) {
      u = 1;
    } else {
      u = -1;
    }

    if (u1 > 0.0F) {
      u_0 = 1;
    } else {
      u_0 = -1;
    }

    y = (real32_T)atan2((real32_T)u, (real32_T)u_0);
  } else if (u1 == 0.0F) {
    if (u0 > 0.0F) {
      y = RT_PIF / 2.0F;
    } else if (u0 < 0.0F) {
      y = -(RT_PIF / 2.0F);
    } else {
      y = 0.0F;
    }
  } else {
    y = (real32_T)atan2(u0, u1);
  }

  return y;
}

/* Initial conditions for root system: '<Root>' */
#define MDL_INITIALIZE_CONDITIONS

static void mdlInitializeConditions(SimStruct *S)
{
  int32_T j;
  for (j = 0; j < 256; j++) {
    /* InitializeConditions for S-Function (sdspdelay): '<S4>/Delay' */
    ((real32_T *)ssGetDWork(S, 1))[j] = 0.0F;

    /* InitializeConditions for S-Function (sdspdelay): '<S4>/Delay1' */
    ((real32_T *)ssGetDWork(S, 2))[j] = 0.0F;
  }
}

/* Start for root system: '<Root>' */
#define MDL_START

static void mdlStart(SimStruct *S)
{
  /* instance underlying S-Function data */
#if defined(RT_MALLOC) || defined(MATLAB_MEX_FILE)
#  if defined(MATLAB_MEX_FILE)

  /* non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

#  endif

  Noise_malloc(S);
  if (ssGetErrorStatus(S) != (NULL) ) {
    return;
  }

#endif

  {
    int32_T i;

    /* InitializeConditions for Enabled SubSystem: '<S2>/Noise Average' */
    /* InitializeConditions for S-Function (sdspstatfcns): '<S7>/Mean' */
    ((uint32_T *)ssGetDWork(S, 4))[0] = 0U;

    /* InitializeConditions for Enabled SubSystem: '<S4>/Maximum value of noise' */
    for (i = 0; i < 256; i++) {
      /* InitializeConditions for Memory: '<S10>/Memory' */
      ((real_T *)ssGetDWork(S, 0))[i] = 0.0;
      ((real32_T *)ssGetDWork(S, 3))[i] = 0.0F;
    }

    /* End of InitializeConditions for S-Function (sdspstatfcns): '<S7>/Mean' */
    /* End of InitializeConditions for SubSystem: '<S4>/Maximum value of noise' */
    /* End of InitializeConditions for SubSystem: '<S2>/Noise Average' */
  }
}

/* Outputs for root system: '<Root>' */
static void mdlOutputs(SimStruct *S, int_T tid)
{
  int32_T index;
  real32_T my;
  real32_T mu;
  real32_T y[256];
  real32_T d_y;
  real32_T e_y;
  real32_T rtb_y[256];
  real32_T rtb_ComplextoMagnitudeAngle_o1[256];
  int32_T i;
  real32_T rtb_y_m;
  real_T u;
  B_Noise_T *_rtB;
  _rtB = ((B_Noise_T *) ssGetLocalBlockIO(S));

  /* Outputs for Enabled SubSystem: '<S4>/Maximum value of noise' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  for (i = 0; i < 256; i++) {
    /* ComplexToMagnitudeAngle: '<S1>/Complex to Magnitude-Angle' incorporates:
     *  Inport: '<Root>/In1'
     */
    my = Noise_rt_hypotf_snf(((const creal32_T **)ssGetInputPortSignalPtrs(S, 0))
      [i]->re, ((const creal32_T **)ssGetInputPortSignalPtrs(S, 0))[i]->im);

    /* Inport: '<Root>/VAD' */
    if (*((const boolean_T **)ssGetInputPortSignalPtrs(S, 1))[0]) {
      /* Gain: '<S10>/Gain' incorporates:
       *  Memory: '<S10>/Memory'
       */
      u = 0.999 * ((real_T *)ssGetDWork(S, 0))[i];

      /* MinMax: '<S10>/MinMax' */
      if ((my >= u) || rtIsNaN(u)) {
        _rtB->MinMax[i] = my;
      } else {
        _rtB->MinMax[i] = u;
      }

      /* End of MinMax: '<S10>/MinMax' */
    }

    /* ComplexToMagnitudeAngle: '<S1>/Complex to Magnitude-Angle' */
    rtb_ComplextoMagnitudeAngle_o1[i] = my;
  }

  /* End of Outputs for SubSystem: '<S4>/Maximum value of noise' */

  /* Outputs for Enabled SubSystem: '<S2>/Noise Average' incorporates:
   *  EnablePort: '<S7>/Enable'
   */
  /* Inport: '<Root>/VAD' */
  if (*((const boolean_T **)ssGetInputPortSignalPtrs(S, 1))[0]) {
    /* S-Function (sdspstatfcns): '<S7>/Mean' */
    index = 0;
    ((uint32_T *)ssGetDWork(S, 4))[0] = ((uint32_T *)ssGetDWork(S, 4))[0] + 1U;
    if (((uint32_T *)ssGetDWork(S, 4))[0] > 1U) {
      for (i = 0; i < 256; i++) {
        ((real32_T *)ssGetDWork(S, 3))[i] = ((real32_T *)ssGetDWork(S, 3))[i] +
          rtb_ComplextoMagnitudeAngle_o1[index];
        _rtB->Mean[index] = ((real32_T *)ssGetDWork(S, 3))[i] / (real32_T)
          ((uint32_T *)ssGetDWork(S, 4))[0];
        index++;
      }
    } else {
      if (((uint32_T *)ssGetDWork(S, 4))[0] == 0U) {
        ((uint32_T *)ssGetDWork(S, 4))[0] = 1U;
      }

      for (i = 0; i < 256; i++) {
        ((real32_T *)ssGetDWork(S, 3))[i] = rtb_ComplextoMagnitudeAngle_o1[index];
        index++;
        _rtB->Mean[i] = rtb_ComplextoMagnitudeAngle_o1[i];
      }
    }

    /* End of S-Function (sdspstatfcns): '<S7>/Mean' */
  }

  /* End of Outputs for SubSystem: '<S2>/Noise Average' */

  /* MATLAB Function: '<S2>/Embedded MATLAB Function' */
  /* MATLAB Function 'Noise canceller/Bias Removal/Embedded MATLAB Function': '<S6>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S6>:1:5' */
  mu = rtb_ComplextoMagnitudeAngle_o1[0];
  for (index = 0; index < 255; index++) {
    mu += rtb_ComplextoMagnitudeAngle_o1[index + 1];
  }

  my = mu / 256.0F;

  /* '<S6>:1:6' */
  mu = _rtB->Mean[0];
  for (index = 0; index < 255; index++) {
    mu += _rtB->Mean[index + 1];
  }

  mu /= 256.0F;

  /* '<S6>:1:8' */
  for (i = 0; i < 256; i++) {
    rtb_y_m = rtb_ComplextoMagnitudeAngle_o1[i] - my;
    y[i] = rtb_y_m * rtb_y_m;
  }

  d_y = y[0];
  for (index = 0; index < 255; index++) {
    d_y += y[index + 1];
  }

  /* '<S6>:1:9' */
  for (i = 0; i < 256; i++) {
    rtb_y_m = _rtB->Mean[i] - mu;
    y[i] = rtb_y_m * rtb_y_m;
  }

  e_y = y[0];
  for (index = 0; index < 255; index++) {
    e_y += y[index + 1];
  }

  /* '<S6>:1:11' */
  for (i = 0; i < 256; i++) {
    rtb_y_m = (rtb_ComplextoMagnitudeAngle_o1[i] - my) * (_rtB->Mean[i] - mu);
    y[i] = (real32_T)fabs(rtb_y_m);
    rtb_y[i] = rtb_y_m;
  }

  mu = y[0];
  for (index = 0; index < 255; index++) {
    mu += y[index + 1];
  }

  /* '<S6>:1:13' */
  mu = mu / 256.0F / (real32_T)sqrt(d_y / 256.0F * (e_y / 256.0F));

  /* '<S6>:1:15' */
  for (i = 0; i < 256; i++) {
    /* Math: '<S2>/Math Function1' incorporates:
     *  Gain: '<S2>/Gain1'
     *  MATLAB Function: '<S2>/Embedded MATLAB Function'
     *  ManualSwitch: '<S1>/Manual Switch2'
     *  Math: '<S2>/Math Function'
     *  Math: '<S2>/Math Function3'
     *  Sum: '<S2>/Add'
     *  Sum: '<S2>/Add1'
     */
    my = (Noise_rt_powf_snf(rtb_ComplextoMagnitudeAngle_o1[i], 2.0F) - 1.8F *
          Noise_rt_powf_snf(_rtB->Mean[i], 2.0F)) -
      rtb_ComplextoMagnitudeAngle_o1[i] * _rtB->Mean[i] * mu;
    if (my < 0.0F) {
      my = -Noise_rt_powf_snf(-my, 0.5F);
    } else {
      my = Noise_rt_powf_snf(my, 0.5F);
    }

    /* End of Math: '<S2>/Math Function1' */

    /* Sum: '<S3>/Add1' incorporates:
     *  ManualSwitch: '<S1>/Manual Switch1'
     */
    my += (real32_T)fabs(my);

    /* ManualSwitch: '<S1>/Manual Switch1' incorporates:
     *  Constant: '<S8>/Constant'
     *  Gain: '<S3>/Gain'
     *  Gain: '<S3>/Gain1'
     *  Product: '<S3>/Divide'
     *  RelationalOperator: '<S8>/Compare'
     *  Sum: '<S3>/Add'
     */
    _rtB->ManualSwitch1[i] = 0.02F * _rtB->Mean[i] * (real32_T)(my == 0.0F) +
      0.5F * my;
  }

  /* MATLAB Function 'Noise canceller/Residual noise reduction/Embedded MATLAB Function': '<S9>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S9>:1:6' */
  /* '<S9>:1:8' */
  for (index = 0; index < 256; index++) {
    /* S-Function (sdspdelay): '<S4>/Delay' */
    _rtB->Delay[index] = ((real32_T *)ssGetDWork(S, 1))[index];

    /* MinMax: '<S4>/MinMax' */
    if ((_rtB->ManualSwitch1[index] <= _rtB->Delay[index]) || rtIsNaNF
        (_rtB->Delay[index])) {
      my = _rtB->ManualSwitch1[index];
    } else {
      my = _rtB->Delay[index];
    }

    /* MATLAB Function: '<S4>/Embedded MATLAB Function' */
    rtb_y[index] = _rtB->ManualSwitch1[index];

    /* '<S9>:1:8' */
    if (_rtB->ManualSwitch1[index] < _rtB->MinMax[index]) {
      /* MinMax: '<S4>/MinMax' incorporates:
       *  S-Function (sdspdelay): '<S4>/Delay1'
       */
      /* '<S9>:1:9' */
      /* '<S9>:1:10' */
      if ((my <= ((real32_T *)ssGetDWork(S, 2))[index]) || rtIsNaNF(((real32_T *)
            ssGetDWork(S, 2))[index])) {
        rtb_y[index] = my;
      } else {
        rtb_y[index] = ((real32_T *)ssGetDWork(S, 2))[index];
      }
    }

    /* End of MATLAB Function: '<S4>/Embedded MATLAB Function' */
    /* '<S9>:1:8' */
  }

  for (i = 0; i < 256; i++) {
    /* ComplexToMagnitudeAngle: '<S1>/Complex to Magnitude-Angle' incorporates:
     *  Inport: '<Root>/In1'
     */
    my = Noise_rt_atan2f_snf(((const creal32_T **)ssGetInputPortSignalPtrs(S, 0))
      [i]->im, ((const creal32_T **)ssGetInputPortSignalPtrs(S, 0))[i]->re);

    /* MagnitudeAngleToComplex: '<S1>/Magnitude-Angle to Complex' incorporates:
     *  ManualSwitch: '<S1>/Manual Switch'
     *  Outport: '<Root>/Out1'
     */
    ((creal32_T *)ssGetOutputPortSignal(S, 0))[i].re = rtb_y[i] * (real32_T)cos
      (my);
    ((creal32_T *)ssGetOutputPortSignal(S, 0))[i].im = rtb_y[i] * (real32_T)sin
      (my);
  }

  UNUSED_PARAMETER(tid);
}

/* Update for root system: '<Root>' */
#define MDL_UPDATE

static void mdlUpdate(SimStruct *S, int_T tid)
{
  int32_T i;
  B_Noise_T *_rtB;
  _rtB = ((B_Noise_T *) ssGetLocalBlockIO(S));

  /* Update for Enabled SubSystem: '<S4>/Maximum value of noise' incorporates:
   *  Update for EnablePort: '<S10>/Enable'
   */
  for (i = 0; i < 256; i++) {
    /* Update for Inport: '<Root>/VAD' */
    if (*((const boolean_T **)ssGetInputPortSignalPtrs(S, 1))[0]) {
      /* Update for Memory: '<S10>/Memory' */
      ((real_T *)ssGetDWork(S, 0))[i] = _rtB->MinMax[i];
    }

    /* End of Update for Inport: '<Root>/VAD' */

    /* Update for S-Function (sdspdelay): '<S4>/Delay' */
    ((real32_T *)ssGetDWork(S, 1))[i] = _rtB->ManualSwitch1[i];

    /* Update for S-Function (sdspdelay): '<S4>/Delay1' */
    ((real32_T *)ssGetDWork(S, 2))[i] = _rtB->Delay[i];
  }

  /* End of Update for SubSystem: '<S4>/Maximum value of noise' */
  UNUSED_PARAMETER(tid);
}

/* Termination for root system: '<Root>' */
static void mdlTerminate(SimStruct *S)
{

#if defined(RT_MALLOC) || defined(MATLAB_MEX_FILE)

  if (ssGetUserData(S) != (NULL) ) {
    rt_FREE(ssGetLocalBlockIO(S));
  }

  rt_FREE(ssGetUserData(S));

#endif

}

#if defined(RT_MALLOC) || defined(MATLAB_MEX_FILE)
#  include "Noise_mid.h"
#endif

/* Function to initialize sizes. */
static void mdlInitializeSizes(SimStruct *S)
{
  ssSetNumSampleTimes(S, 1);           /* Number of sample times */
  ssSetNumContStates(S, 0);            /* Number of continuous states */
  ssSetNumNonsampledZCs(S, 0);         /* Number of nonsampled ZCs */

  /* Number of output ports */
  if (!ssSetNumOutputPorts(S, 1))
    return;

  /* outport number: 0 */
  if (!ssSetOutputPortMatrixDimensions(S, 0, 256, 1))
    return;
  if (ssGetSimMode(S) != SS_SIMMODE_SIZES_CALL_ONLY) {
    ssSetOutputPortDataType(S, 0, SS_SINGLE);
  }

  ssSetOutputPortComplexSignal(S, 0, COMPLEX_YES);
  ssSetOutputPortSampleTime(S, 0, 0.016);
  ssSetOutputPortOffsetTime(S, 0, 0.0);
  ssSetOutputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);

  /* Number of input ports */
  if (!ssSetNumInputPorts(S, 2))
    return;

  /* inport number: 0 */
  {
    if (!ssSetInputPortMatrixDimensions(S, 0, 256, 1))
      return;
    if (ssGetSimMode(S) != SS_SIMMODE_SIZES_CALL_ONLY) {
      ssSetInputPortDataType(S, 0, SS_SINGLE);
    }

    ssSetInputPortComplexSignal(S, 0, COMPLEX_YES);
    ssSetInputPortDirectFeedThrough(S, 0, 1);
    ssSetInputPortSampleTime(S, 0, 0.016);
    ssSetInputPortOffsetTime(S, 0, 0.0);
    ssSetInputPortOverWritable(S, 0, 0);
    ssSetInputPortOptimOpts(S, 0, SS_NOT_REUSABLE_AND_GLOBAL);
  }

  /* inport number: 1 */
  {
    if (!ssSetInputPortMatrixDimensions(S, 1, 1, 1))
      return;
    if (ssGetSimMode(S) != SS_SIMMODE_SIZES_CALL_ONLY) {
      ssSetInputPortDataType(S, 1, SS_BOOLEAN);
    }

    ssSetInputPortDirectFeedThrough(S, 1, 1);
    ssSetInputPortSampleTime(S, 1, 0.016);
    ssSetInputPortOffsetTime(S, 1, 0.0);
    ssSetInputPortOverWritable(S, 1, 0);
    ssSetInputPortOptimOpts(S, 1, SS_NOT_REUSABLE_AND_GLOBAL);
  }

  ssSetRTWGeneratedSFcn(S, 1);         /* Generated S-function */

  /* DWork */
  if (!ssSetNumDWork(S, 5)) {
    return;
  }

  /* '<S10>/Memory': PreviousInput */
  ssSetDWorkName(S, 0, "DWORK0");
  ssSetDWorkWidth(S, 0, 256);

  /* '<S4>/Delay': IC_BUFF */
  ssSetDWorkName(S, 1, "DWORK1");
  ssSetDWorkWidth(S, 1, 256);
  ssSetDWorkDataType(S, 1, SS_SINGLE);
  ssSetDWorkUsedAsDState(S, 1, 1);

  /* '<S4>/Delay1': IC_BUFF */
  ssSetDWorkName(S, 2, "DWORK2");
  ssSetDWorkWidth(S, 2, 256);
  ssSetDWorkDataType(S, 2, SS_SINGLE);
  ssSetDWorkUsedAsDState(S, 2, 1);

  /* '<S7>/Mean': AccVal */
  ssSetDWorkName(S, 3, "DWORK3");
  ssSetDWorkWidth(S, 3, 256);
  ssSetDWorkDataType(S, 3, SS_SINGLE);

  /* '<S7>/Mean': Iteration */
  ssSetDWorkName(S, 4, "DWORK4");
  ssSetDWorkWidth(S, 4, 1);
  ssSetDWorkDataType(S, 4, SS_UINT32);

  /* Tunable Parameters */
  ssSetNumSFcnParams(S, 0);

  /* Number of expected parameters */
#if defined(MATLAB_MEX_FILE)

  if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {

#if defined(MDL_CHECK_PARAMETERS)

    mdlCheckParameters(S);

#endif                                 /* MDL_CHECK_PARAMETERS */

    if (ssGetErrorStatus(S) != (NULL) ) {
      return;
    }
  } else {
    return;                            /* Parameter mismatch will be reported by Simulink */
  }

#endif                                 /* MATLAB_MEX_FILE */

  /* Options */
  ssSetOptions(S, (SS_OPTION_RUNTIME_EXCEPTION_FREE_CODE |
                   SS_OPTION_PORT_SAMPLE_TIMES_ASSIGNED ));

#if SS_SFCN_FOR_SIM

  {
    ssSupportsMultipleExecInstances(S, true);
    ssHasStateInsideForEachSS(S, false);
  }

#endif

}

/* Function to initialize sample times. */
static void mdlInitializeSampleTimes(SimStruct *S)
{
  /* task periods */
  ssSetSampleTime(S, 0, 0.016);

  /* task offsets */
  ssSetOffsetTime(S, 0, 0.0);
}

#if defined(MATLAB_MEX_FILE)
# include "fixedpoint.c"
# include "simulink.c"
#else
# undef S_FUNCTION_NAME
# define S_FUNCTION_NAME               Noise_sf
# include "cg_sfun.h"
#endif                                 /* defined(MATLAB_MEX_FILE) */
