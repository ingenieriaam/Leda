/*
 * Noise_sf_types.h
 *
 * Code generation for model "Noise_sf".
 *
 * Model version              : 1.86
 * Simulink Coder version : 8.5 (R2013b) 08-Aug-2013
 * C source code generated on : Sat Jun 06 03:19:03 2015
 *
 * Target selection: rtwsfcn.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: TI C6000
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_Noise_sf_types_h_
#define RTW_HEADER_Noise_sf_types_h_
#endif                                 /* RTW_HEADER_Noise_sf_types_h_ */
