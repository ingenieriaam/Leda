/*
 * Noise_sf.h
 *
 * Code generation for model "Noise_sf".
 *
 * Model version              : 1.86
 * Simulink Coder version : 8.5 (R2013b) 08-Aug-2013
 * C source code generated on : Sat Jun 06 03:19:03 2015
 *
 * Target selection: rtwsfcn.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: TI C6000
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_Noise_sf_h_
#define RTW_HEADER_Noise_sf_h_
#ifndef Noise_sf_COMMON_INCLUDES_
# define Noise_sf_COMMON_INCLUDES_
#include <stdlib.h>
#include <stddef.h>
#include <math.h>
#include <string.h>
#define S_FUNCTION_NAME                Noise_sf
#define S_FUNCTION_LEVEL               2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "multiword_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"
#include "rtGetNaN.h"
#include "rt_defines.h"
#if !defined(MATLAB_MEX_FILE)
#include "rt_matrx.h"
#endif

#if !defined(RTW_SFUNCTION_DEFINES)
#define RTW_SFUNCTION_DEFINES

typedef struct {
  void *blockIO;
  void *defaultParam;
  void *nonContDerivSig;
} LocalS;

#define ssSetLocalBlockIO(S, io)       ((LocalS *)ssGetUserData(S))->blockIO = ((void *)(io))
#define ssGetLocalBlockIO(S)           ((LocalS *)ssGetUserData(S))->blockIO
#define ssSetLocalDefaultParam(S, paramVector) ((LocalS *)ssGetUserData(S))->defaultParam = (paramVector)
#define ssGetLocalDefaultParam(S)      ((LocalS *)ssGetUserData(S))->defaultParam
#define ssSetLocalNonContDerivSig(S, pSig) ((LocalS *)ssGetUserData(S))->nonContDerivSig = (pSig)
#define ssGetLocalNonContDerivSig(S)   ((LocalS *)ssGetUserData(S))->nonContDerivSig
#endif
#endif                                 /* Noise_sf_COMMON_INCLUDES_ */

#include "Noise_sf_types.h"

/* Block signals (auto storage) */
typedef struct {
  real_T MinMax[256];                  /* '<S10>/MinMax' */
  real32_T ManualSwitch1[256];         /* '<S1>/Manual Switch1' */
  real32_T Delay[256];                 /* '<S4>/Delay' */
  real32_T Mean[256];                  /* '<S7>/Mean' */
} B_Noise_T;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  creal32_T *In1[256];                 /* '<Root>/In1' */
  boolean_T *VAD;                      /* '<Root>/VAD' */
} ExternalUPtrs_Noise_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  creal32_T *Out1[256];                /* '<Root>/Out1' */
} ExtY_Noise_T;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('noise_suppressor/Noise canceller')    - opens subsystem noise_suppressor/Noise canceller
 * hilite_system('noise_suppressor/Noise canceller/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'noise_suppressor'
 * '<S1>'   : 'noise_suppressor/Noise canceller'
 * '<S2>'   : 'noise_suppressor/Noise canceller/Bias Removal'
 * '<S3>'   : 'noise_suppressor/Noise canceller/Half-wave Rectification'
 * '<S4>'   : 'noise_suppressor/Noise canceller/Residual noise reduction'
 * '<S5>'   : 'noise_suppressor/Noise canceller/Bias Removal/DocBlock'
 * '<S6>'   : 'noise_suppressor/Noise canceller/Bias Removal/Embedded MATLAB Function'
 * '<S7>'   : 'noise_suppressor/Noise canceller/Bias Removal/Noise Average'
 * '<S8>'   : 'noise_suppressor/Noise canceller/Half-wave Rectification/Compare To Zero'
 * '<S9>'   : 'noise_suppressor/Noise canceller/Residual noise reduction/Embedded MATLAB Function'
 * '<S10>'  : 'noise_suppressor/Noise canceller/Residual noise reduction/Maximum value of noise'
 */
#endif                                 /* RTW_HEADER_Noise_sf_h_ */
