clc;
clear all;
addpath('D:\UTN\DPLAB\Grupo_Audio\repositorio_svn - copia\mFunction'); % Ruta de funciones auxiliares *.m
    

fs = 8000;
len = 1024;

A1 = 0;
A2 = 0;
A3 = 0;
A4 = 10;
A5 = 0;
A6 = 0;
R1 = 5;
R2 = 5;
p = 2;

x1 = tono_ruido(0, fs, len, R1) + A1*tono(440, fs, len) + A2*tono(880, fs, len) + A3*tono(1320, fs, len);

x2 = tono_ruido(0, fs, len, R2) + A4*tono(440, fs, len) + A5*tono(880, fs, len) + A6*tono(1320, fs, len);


[fft_x, fft_y1] = fft_abs(x1,len,fs);
[~, fft_y2] = fft_abs(x2,len,fs);

resp1 = fft_y1.^p;
resp2 = fft_y2.^p;
resp3 = resp1-resp2;
resp4 = abs(resp3);
resp5 = sum(resp1) / sum(resp2);

dif_amp = sum(resp3)/(sum(resp1)+sum(resp2))
dif_frec = sum(resp4)/(sum(resp1)+sum(resp2))
diff_div = dif_amp/dif_frec
diff_resta = dif_amp + dif_frec


sum(resp1)
sum(resp2)
sum(resp3);
sum(resp4);
sum(resp5);

Imprime = '';
Imprime = [Imprime 'P(x1) = ' num2str(sum(resp1)) '\r\n'];
Imprime = [Imprime 'P(x2) = ' num2str(sum(resp2)) '\r\n'];
Imprime = [Imprime 'P(x3) = ' num2str(dif_amp) '\r\n'];
Imprime = [Imprime 'P(x4) = ' num2str(dif_frec) '\r\n'];
Imprime = [Imprime '/: = ' num2str(diff_div) '\r\n'];
Imprime = [Imprime '-: = ' num2str(diff_resta) '\r\n' '\r\n' '\r\n'];


figure(1)
plot([x1 x2]);

figure(2)
subplot(211)
plot(fft_x, resp1);
subplot(212)
plot(fft_x, resp2);

figure(3)
subplot(311)
plot(fft_x, resp3);
subplot(312)
plot(fft_x, resp4);
subplot(313)
plot(fft_x, resp5);



% ****************** GUARDO .TXT ********************** %

[~,struc] = fileattrib;
PathCurrent = struc.Name;   % Obtengo path de la carpeta actual

FolderName = 'Resultados';                          % Nombre de la carpeta a crear
PathFolder = [PathCurrent '\' FolderName];              % Path de mi carpeta
NameFile = [PathFolder '\5R - 10f0+5R.txt'];       % Nombre de mi archivo

if ~exist(PathFolder, 'dir')
    mkdir(PathCurrent, FolderName);     % Creo la carpeta
end

fileID = fopen(NameFile,'a');   % abro archivo como escritura (si existe, la trunca; si no, la crea)

fprintf(fileID, Imprime);

fclose(fileID);                 % Cierro archivo


