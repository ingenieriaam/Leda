function miguide_ploteo()    %----- Datos del usuario -----%

    global app_id;
    global init_guide_flag;
    global window_length;
    global in_total;
    global freq_samp;
    global iter_bloque;
    global iter_muestra;
    global edit_text;
    global edit_text_m;
    global function_text;
    
    if init_guide_flag(app_id) == 0
        Init_miguide();
        init_guide_flag(app_id) = 1;
    end
    
    if iter_muestra(app_id) > window_length(app_id)
        iter_bloque(app_id) = iter_bloque(app_id) + fix(iter_muestra(app_id)/window_length(app_id));
        iter_muestra(app_id) = mod(iter_muestra(app_id),window_length(app_id));
    end
    
    if iter_muestra(app_id) < 1
        iter_bloque(app_id) = iter_bloque(app_id) + fix(iter_muestra(app_id)/window_length(app_id)) - 1;
        if iter_bloque(app_id) < 1
            iter_muestra(app_id) = 1;
        else
            iter_muestra(app_id) = mod(iter_muestra(app_id),window_length(app_id));
        end
    end
    
    if iter_muestra(app_id) == 0
        iter_muestra(app_id) = window_length(app_id);
    end
    
    if iter_bloque(app_id) < 1
        iter_bloque(app_id) = 1;
    end
    
    if iter_bloque(app_id) > fix(length(in_total)/window_length(app_id))
        iter_bloque(app_id) = fix(length(in_total)/window_length(app_id));
    end
    
    set(edit_text(app_id), 'string', iter_bloque(app_id));    
    
    if iter_bloque(app_id) == fix(length(in_total)/window_length(app_id));
        iter_muestra(app_id) = 1;
    end
    
    set(edit_text_m(app_id), 'string', iter_muestra(app_id));
    
    clc;
    in = in_total(:,app_id);
    i_b = iter_bloque(app_id) - 1;
    i_m = iter_muestra(app_id) - 1;
    w_len = window_length(app_id);
    fs = freq_samp(app_id);
    
    func_plot = str2func(get(function_text(app_id), 'string'));
    func_plot(in, i_b, i_m, w_len, fs, 1);
    
    set( gcf, 'toolbar', 'figure' );
    
end