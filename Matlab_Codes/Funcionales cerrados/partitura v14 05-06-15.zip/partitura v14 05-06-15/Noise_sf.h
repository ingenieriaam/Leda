/*
* Generated S-function Target for model Noise. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Sat Jun 06 03:19:03 2015
*/

#ifndef RTWSFCN_Noise_sf_H
#define RTWSFCN_Noise_sf_H

#include "Noise_sfcn_rtw\Noise_sf.h"
  #include "Noise_sfcn_rtw\Noise_sf_private.h"

#endif
