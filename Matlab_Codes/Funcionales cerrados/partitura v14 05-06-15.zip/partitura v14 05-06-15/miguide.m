function varargout = miguide(varargin)
    % MIGUIDE MATLAB code for miguide.fig
    %      MIGUIDE, by itself, creates a new MIGUIDE or raises the existing
    %      singleton*.
    %
    %      H = MIGUIDE returns the handle to a new MIGUIDE or the handle to
    %      the existing singleton*.
    %
    %      MIGUIDE('CALLBACK',hObject,eventData,handles,...) calls the local
    %      function named CALLBACK in MIGUIDE.M with the given input arguments.
    %
    %      MIGUIDE('Property','Value',...) creates a new MIGUIDE or raises the
    %      existing singleton*.  Starting from the left, property value pairs are
    %      applied to the GUI before miguide_OpeningFcn gets called.  An
    %      unrecognized property name or invalid value makes property application
    %      stop.  All inputs are passed to miguide_OpeningFcn via varargin.
    %
    %      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
    %      instance to run (singleton)".
    %
    % See also: GUIDE, GUIDATA, GUIHANDLES

    % Edit the above text to modify the response to help miguide

    % Last Modified by GUIDE v2.5 29-May-2015 12:45:07

    % Begin initialization code - DO NOT EDIT
    gui_Singleton = 0;
    gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @miguide_OpeningFcn, ...
                   'gui_OutputFcn',  @miguide_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before miguide is made visible.
function miguide_OpeningFcn(hObject, eventdata, handles, varargin)
    % This function has no output args, see OutputFcn.
    % hObject    handle to figure
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    % varargin   command line arguments to miguide (see VARARGIN)

    % Choose default command line output for miguide
    handles.output = hObject;

    % Update handles structure
    guidata(hObject, handles);

    % UIWAIT makes miguide wait for user response (see UIRESUME)
    % uiwait(handles.figure1);


    % --- Outputs from this function are returned to the command line.
function varargout = miguide_OutputFcn(hObject, eventdata, handles) 
    % varargout  cell array for returning output args (see VARARGOUT);
    % hObject    handle to figure
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    % Get default command line output from handles structure
    varargout{1} = handles.output;


    % --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton4 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    
    global app_id;
    global edit_text;
    global edit_text_m;
    global iter_bloque;
    global iter_muestra;
    global pushbutton4_hObject;
    
    for app_id = 1:length(pushbutton4_hObject)
        if pushbutton4_hObject(app_id) == hObject;
            break;
        end
    end
    
    str = get(edit_text(app_id), 'string');
    iter_bloque(app_id) = str2num(str);
    
    str = get(edit_text_m(app_id), 'string');
    iter_muestra(app_id) = str2num(str);
    
    miguide_ploteo();


    % --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to figure1 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called
    
    
    if length(findobj('Type','figure')) == 1
        clc;
        clear all;        
    end
    
    global app_id;
    global init_guide_flag;
    
    addpath('./funciones'); % Ruta de los archivos *.m que analizan el audio
            
    if isempty(app_id)
        app_id = 0;
    end
    if app_id < 0
        app_id = 0;
    end
    app_id = fix(app_id + 1);
    init_guide_flag(app_id) = 0;



    % --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to edit1 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    
    global app_id;
    global edit_text;
    edit_text(app_id) = hObject;
    
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



    % --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to edit2 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.


    global app_id;
    global function_text;
    function_text(app_id) = hObject;
    
    
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


    % --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to edit3 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    

    global app_id;
    global edit_text_m;
    edit_text_m(app_id) = hObject;
    
    
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit1_Callback(hObject, eventdata, handles)
    % hObject    handle to edit1 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of edit1 as text
    %        str2double(get(hObject,'String')) returns contents of edit1 as a double



function edit2_Callback(hObject, eventdata, handles)
    % hObject    handle to edit2 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of edit2 as text
    %        str2double(get(hObject,'String')) returns contents of edit2 as a double



function edit3_Callback(hObject, eventdata, handles)
    % hObject    handle to edit3 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of edit3 as text
    %        str2double(get(hObject,'String')) returns contents of edit3 as a double


    % --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton3 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    
    
    global app_id;
    global iter_muestra;
    global pushbutton3_hObject;
    
    for app_id = 1:length(pushbutton3_hObject)
        if pushbutton3_hObject(app_id) == hObject;
            break;
        end
    end
    iter_muestra(app_id) = iter_muestra(app_id)+1;
    miguide_ploteo();



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.


    global app_id;
    global audio_text;
    audio_text(app_id) = hObject;
    
    
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


    % --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton6 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)


    global init_guide_flag;
    global app_id;
    global pushbutton6_hObject;
    
    for app_id = 1:length(pushbutton6_hObject)
        if pushbutton6_hObject(app_id) == hObject;
            break;
        end
    end
    
    init_guide_flag(app_id) = 1;
    Init_miguide();


    % --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
    % hObject    handle to popupmenu1 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    % Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
    %        contents{get(hObject,'Value')} returns selected item from popupmenu1

    
    global audio_text;
    global function_text;
    global wlen_text;
    global app_id;
    global popupmenu1_hObject;
    
    for app_id = 1:length(popupmenu1_hObject)
        if popupmenu1_hObject(app_id) == hObject;
            break;
        end
    end
    
    str = get(hObject,'String');
    val = get(hObject,'Value');
    
    switch str{val};
        case 'Elige default' 
            set(audio_text(app_id), 'string', 'Nombre del archivo de audio');
            set(function_text(app_id), 'string', 'Nombre de la funcion de ploteo');
            set(wlen_text(app_id), 'string', 1024);
        case 'prueba' 
            set(audio_text(app_id), 'string', '../../../GUITARRA_cut.wav');
            set(function_text(app_id), 'string', 'prueba');
            set(wlen_text(app_id), 'string', 1024);
        case 'dur_xcorr' 
            set(audio_text(app_id), 'string', 'D:\UTN\DPLAB\Grupo_Audio\repositorio_svn - copia\audios\DURACION\DURACION V8.1 - Reductor\Audios\ex-harmonic.wav');
            set(function_text(app_id), 'string', 'dur_xcorr');
            set(wlen_text(app_id), 'string', 1024);
        case 'dur_prueba' 
            set(audio_text(app_id), 'string', 'D:\UTN\DPLAB\Grupo_Audio\repositorio_svn - copia\audios\DURACION\DURACION V8.1 - Reductor\Audios\b_8_k.wav');
            set(function_text(app_id), 'string', 'dur_prueba');
            set(wlen_text(app_id), 'string', 1024);
    end
    

    
    
    % --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to popupmenu1 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: popupmenu controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.

    global app_id;
    global popupmenu1_hObject;
    
    popupmenu1_hObject(app_id) = hObject;
    
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


    % --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton7 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    
    global audio_text;
    global app_id;
    global pushbutton7_hObject;
    
    for app_id = 1:length(pushbutton7_hObject)
        if pushbutton7_hObject(app_id) == hObject;
            break;
        end
    end
    
    [FileName,PathName,FilterIndex] = uigetfile('*.wav','Elige un audio para analizar');

    if FilterIndex ~= 0
        set(audio_text(app_id), 'string', [PathName FileName]);
    end

    
    
    % --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton8 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)


    global function_text;
    global app_id;
    global pushbutton8_hObject;
    
    for app_id = 1:length(pushbutton8_hObject)
        if pushbutton8_hObject(app_id) == hObject;
            break;
        end
    end
    
    [FileName,PathName,FilterIndex] = uigetfile('*.m','Elige una funcion para realizar el analisis');

    if FilterIndex ~= 0
        [~,name] = fileparts(FileName);
        addpath(PathName);
        set(function_text(app_id), 'string', name);
    end

    
    
    


    % --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton5 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    global app_id;
    global iter_bloque;
    global pushbutton5_hObject;
    
    for app_id = 1:length(pushbutton5_hObject)
        if pushbutton5_hObject(app_id) == hObject;
            break;
        end
    end
    
    iter_bloque(app_id) = iter_bloque(app_id)+1;
    miguide_ploteo();


    % --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton2 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    global app_id;
    global iter_muestra;
    global pushbutton2_hObject;
    
    for app_id = 1:length(pushbutton2_hObject)
        if pushbutton2_hObject(app_id) == hObject;
            break;
        end
    end
    iter_muestra(app_id) = iter_muestra(app_id)-1;
    miguide_ploteo();


    % --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton1 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)


    global app_id;
    global iter_bloque;
    global pushbutton1_hObject;
    
    for app_id = 1:length(pushbutton1_hObject)
        if pushbutton1_hObject(app_id) == hObject;
            break;
        end
    end
    iter_bloque(app_id) = iter_bloque(app_id)-1;
    miguide_ploteo();


% --- Executes on key press with focus on pushbutton4 and none of its controls.
function pushbutton4_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on pushbutton5 and none of its controls.
function pushbutton5_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on pushbutton3 and none of its controls.
function pushbutton3_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on pushbutton2 and none of its controls.
function pushbutton2_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on pushbutton1 and none of its controls.
function pushbutton1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on edit4 and none of its controls.
function edit4_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on pushbutton7 and none of its controls.
function pushbutton7_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on pushbutton8 and none of its controls.
function pushbutton8_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on popupmenu1 and none of its controls.
function popupmenu1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on pushbutton6 and none of its controls.
function pushbutton6_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


    % --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to edit5 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.


    global app_id;
    global salto_text;
    salto_text(app_id) = hObject;
    
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

    
    

    % --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton9 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)


    global app_id;
    global salto_text;
    global iter_muestra;
    global pushbutton9_hObject;
    
    for app_id = 1:length(pushbutton9_hObject)
        if pushbutton9_hObject(app_id) == hObject;
            break;
        end
    end
    
    salto = str2num(get(salto_text(app_id), 'string'));
    
    iter_muestra(app_id) = iter_muestra(app_id) + salto;
    miguide_ploteo();



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


    % --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to edit6 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.


    global app_id;
    global wlen_text;
    wlen_text(app_id) = hObject;
    
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


    % --- Executes during object creation, after setting all properties.
function pushbutton5_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to pushbutton5 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    global app_id;
    global pushbutton5_hObject;
    
    pushbutton5_hObject(app_id) = hObject;


    % --- Executes during object creation, after setting all properties.
function pushbutton4_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to pushbutton4 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    global app_id;
    global pushbutton4_hObject;
    
    pushbutton4_hObject(app_id) = hObject;


    % --- Executes during object creation, after setting all properties.
function pushbutton9_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to pushbutton9 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    global app_id;
    global pushbutton9_hObject;
    
    pushbutton9_hObject(app_id) = hObject;


    % --- Executes during object creation, after setting all properties.
function pushbutton3_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to pushbutton3 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    global app_id;
    global pushbutton3_hObject;
    
    pushbutton3_hObject(app_id) = hObject;


    % --- Executes during object creation, after setting all properties.
function pushbutton2_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to pushbutton2 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    global app_id;
    global pushbutton2_hObject;
    
    pushbutton2_hObject(app_id) = hObject;


    % --- Executes during object creation, after setting all properties.
function pushbutton1_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to pushbutton1 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    global app_id;
    global pushbutton1_hObject;
    
    pushbutton1_hObject(app_id) = hObject;


    % --- Executes during object creation, after setting all properties.
function pushbutton6_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to pushbutton6 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    global app_id;
    global pushbutton6_hObject;
    
    pushbutton6_hObject(app_id) = hObject;


    % --- Executes during object creation, after setting all properties.
function pushbutton8_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to pushbutton8 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    global app_id;
    global pushbutton8_hObject;
    
    pushbutton8_hObject(app_id) = hObject;


    % --- Executes during object creation, after setting all properties.
function pushbutton7_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to pushbutton7 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    global app_id;
    global pushbutton7_hObject;
    
    pushbutton7_hObject(app_id) = hObject;
