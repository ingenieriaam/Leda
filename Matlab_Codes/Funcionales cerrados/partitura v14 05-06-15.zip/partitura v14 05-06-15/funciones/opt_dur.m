function out = opt_dur(nota)

    out = nota(1);
    
    for i = 2:length(nota)
        if( (nota(i) == 1) && (nota(i-1) == 0) )
            out(i) = 0;
        elseif nota(i) == 2
            out(i-1) = 0;
            out(i) = nota(i);
        else
            out(i) = nota(i);
        end
    end

end