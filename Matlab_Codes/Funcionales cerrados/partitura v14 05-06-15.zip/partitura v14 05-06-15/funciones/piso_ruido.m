function [ nivel ] = piso_ruido( signal,fs )
%PISO_RUIDO halla un piso de ruido dinamico
  
  L = length(signal);
  NFFT = 2^nextpow2(L);
  fft_s = fft(signal,NFFT)/L;
  f = fs/2*linspace(0,1,NFFT/2+1);
  espectro = abs(fft_s(1:NFFT/2+1));
%   semilogx(f,(abs(fft_s(1:NFFT/2+1)))), axis tight,xlim([1 20000]),grid;
%     set(gca,'XTickLabel',{'1','10','100','1K','10K'});
%     title('Single-Sided Amplitude Spectrum of s(t)');
%     xlabel('Frequency (Hz)');
%     ylabel('|S(f)|');
%     
    
%   [d,m]=max(espectro);
%   if m > 1
%     espectro(m-2:m+2)=0;
%   end
%   
%   [c,i]=max(espectro);
%   if i > 1
%     espectro(i-1:i+1)=0;
%   end
%   
%   [c,i]=max(espectro);
%   if i > 1
%     espectro(i-2:i+2)=0;
%   end
  
  s=sum(espectro)/L;
  nivel =  s*30;
% 
%     hold on;
%     plot(ones(L,1)*nivel,'r');
  
end

