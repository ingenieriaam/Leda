function nota = dur_prueba(in, i_b, i_m, w_len, fs, ploteo)

    persistent first_time;
    persistent window;
    persistent bloque_ant;
    persistent ruido;
    persistent ruido_2;
    persistent p;
    persistent flag_nota;   % Flag de cuando arranca y termina una nota
    persistent piso_x4_0;
    persistent piso_div_0;
    persistent piso_resta_0;
    persistent piso_div;    % Piso de la diferencia del bloque actual con el anterior
    persistent piso_resta;  % Piso de la diferencia del bloque actual con el anterior
    persistent piso_div_2;    % Piso de la diferencia del bloque actual con el anterior
    persistent piso_resta_2;  % Piso de la diferencia del bloque actual con el anterior
    persistent piso_ruido;
    persistent vista;       % Para que no se resetee la vista de los plots
    
    if isempty(first_time)
    	window = hanning(w_len,'periodic');
        bloque_ruido = in( 1 : w_len );
        bloque_ruido = bloque_ruido .* window;
        [~, fft_y] = fft_abs(bloque_ruido,w_len,fs);
        p = 2;
        ruido = sum(fft_y);
        ruido_2 = sum(fft_y.^2);
        flag_nota = 0;
    
        first_time = 1;
    end
    
    piso_ruido = 10;

    piso_x4_0 = 0.8;
    piso_div_0 = 0.9;
    piso_resta_0 = 1.9;
    
    piso_div = 0.7;
    piso_resta = 1;

    piso_div_2 = 0.6;
    piso_resta_2 = 0.6;
    vista = 50;
    
    if length(window) ~= w_len
    	window = hanning(w_len,'periodic');
        bloque_ruido = in( 1 : w_len );
        bloque_ruido = bloque_ruido .* window;
        [~, fft_y] = fft_abs(bloque_ruido,w_len,fs);
        ruido = sum(fft_y);
        ruido_2 = sum(fft_y.^2);
        bloque = in( (w_len*i_b)+1+i_m : w_len*(i_b+1)+i_m);
        bloque = bloque .* window;
        bloque_ant = bloque;
    end
    
    bloque = in( (w_len*i_b)+1+i_m : w_len*(i_b+1)+i_m);
    bloque = bloque .* window;
    
    if isempty(bloque_ant)
        bloque_ant = bloque;
    end
    
    
    [fft_x, fft_y1] = fft_abs(bloque_ant,length(bloque_ant),fs);
    [~, fft_y2] = fft_abs(bloque,length(bloque),fs);
    

    resp1 = fft_y1.^p;
    resp2 = fft_y2.^p;
    resp3 = (resp2-resp1) / (sum(resp1) + sum(resp2));
    resp4 = abs(resp3);

    dif_amp = sum(resp3);
    dif_frec = sum(resp4);
    diff_div = dif_amp/dif_frec;
    diff_resta = dif_amp + dif_frec;

    
    if ploteo
        
        if (sum(resp1) > piso_ruido*(ruido_2)) || (sum(resp2) > piso_ruido*(ruido_2))
                % Notas fuertes
            if ((sum(resp1) > ruido) || (sum(resp2) > ruido)) && (diff_div+dif_frec+diff_resta > 1.8)
                disp('EMPIEZA NOTA');
                disp(' ');
            end
                % Notas suaves
            if (sum(resp1) < ruido) && (sum(resp2) < ruido) && (diff_div > piso_div_2) && (diff_resta > piso_resta_2)
                disp('EMPIEZA NOTA');
                disp(' ');
            end
        end
        
        disp(['P(x1) = ' num2str(sum(resp1))]);
        disp(['P(x2) = ' num2str(sum(resp2))]);
        disp(['P(x3) = ' num2str(dif_amp)]);
        disp(['P(x4) = ' num2str(dif_frec)]);
        disp(['/: = ' num2str(diff_div)]);
        disp(['-: = ' num2str(diff_resta)]);
        disp(['ruido: = ' num2str(ruido)]);
        disp(['ruido_2: = ' num2str(ruido_2)]);
    
    
        ax1 = subplot(311);
            plot(in);
            hold on;
            plot((w_len*i_b)+1+i_m : w_len*(i_b+1)+i_m, bloque, 'r');
            hold off;
            axis(ax1, [(w_len*(i_b-vista))+1+i_m w_len*(i_b+1+vista)+i_m -1 1]);    % limites de los ejes
            
        ax2 = subplot(312);
            plot(bloque);
            
        ax3 = subplot(313);
            plot(fft_x, resp4);
            axis(ax3, [0 4000 0 1]);    % limites de los ejes

        %linkaxes([ax1 ax2], ['x' 'y']);     % Linkea ejes
        %axis([ax1 ax2 ax3], [0 4000 -2 2]);    % limites de los ejes

        sound(bloque, fs);
        
    end

    bloque_ant = bloque;
    
    nota = 0;
    if (sum(resp1) > piso_ruido*(ruido_2)) || (sum(resp2) > piso_ruido*(ruido_2))
            % Notas fuertes
        if ((sum(resp1) > ruido) || (sum(resp2) > ruido)) && (diff_div+dif_frec+diff_resta > 1.8)
            nota = 2;
            flag_nota = 2;
            
            % Notas suaves
        elseif (sum(resp1) < ruido) && (sum(resp2) < ruido) && (diff_div > piso_div_2) && (diff_resta > piso_resta_2)
            nota = 2;
            flag_nota = 2;
        
        elseif  (flag_nota > 0)
            nota = 1;
            flag_nota = 1;
        end
    else
        flag_nota = 0;
    end
    %{
    if (sum(resp1) > piso_ruido*(ruido_2)) || (sum(resp2) > piso_ruido*(ruido_2))
            % Notas fuertes
        if ((sum(resp1) > ruido) || (sum(resp2) > ruido)) && (diff_div > piso_div || dif_frec > piso_x4) && (diff_resta > piso_resta)
            nota = 1;
        end
            % Notas suaves
        if (sum(resp1) < ruido) && (sum(resp2) < ruido) && (diff_div > piso_div_2) && (diff_resta > piso_resta_2)
            nota = 1;
        end
    end
    %}
        
end







