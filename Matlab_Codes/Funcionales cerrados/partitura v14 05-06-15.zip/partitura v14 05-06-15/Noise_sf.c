/*
 * Generated S-function Target for model Noise. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Sat Jun 06 03:19:03 2015
 */

#include "Noise_sf.h"
#include "Noise_sfcn_rtw\Noise_sf.c"


